/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package toyotacompany;
import javax.swing.JOptionPane;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author musa
 */
public class Ownerlogin {
    public void Ownerlogin(String name,String password){
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/toyotacompany_db","root","musa220349@");
           // String query= "insert into owner(name,password) values('"+name+"','"+password+"')";
           // Statement statement= con.createStatement();
           // statement.executeUpdate(query);
           String query = "Select * from owner where name=? AND password=?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, name);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                new Bookinglist().setVisible(true);
            }
            else{
                JOptionPane.showMessageDialog(null, "Invalaid Login");
            }
             
        } 
        catch (SQLException ex) {
            Logger.getLogger(Ownerlogin.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println(ex.getMessage());
        }
    }
}
