/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package toyotacompany;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author musa
 */
public class Logincustomer {
    public void registerdata(String name,String password){
        try {
            Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/toyotacompany_db", "root", "musa220349@");
            System.out.println("Connection Established");  
            String query= "insert into login(name,password) values('"+name+"','"+password+"')";
            Statement statement= con.createStatement();
            statement.executeUpdate(query);
        } 
        catch (SQLException ex) {
            Logger.getLogger(Logincustomer.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println(ex.getMessage());
        }
    }
}
