/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package toyotacompany;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author musa
 */
public class Registration {
    public void registerdataa(String name,String fathername,String address,String phone,String cnic,String email,String password,String gender,String cardname,String cardnumber,String mmyy,String cvv,String carname,String color){
        try {
            Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/toyotacompany_db", "root", "musa220349@");  
            System.out.println("Connection Established");
            String query= "insert into registration(name,fathername,address,phone,cnic,email,password,gender,cardname,cardnumber,mmyy,cvv,carname,color) values('"+name+"','"+fathername+"','"+address+"','"+phone+"','"+cnic+"','"+email+"','"+password+"','"+gender+"','"+cardname+"','"+cardnumber+"','"+mmyy+"','"+cvv+"','"+carname+"','"+color+"')";
            Statement statement= con.createStatement();
            statement.executeUpdate(query);
        }
        
        
        catch (SQLException ex) {
           // Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
             System.out.println(ex.getMessage());
        }
        
    }
}
